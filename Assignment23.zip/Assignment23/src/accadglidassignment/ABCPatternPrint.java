package accadglidassignment;

public class ABCPatternPrint {
	public static void main(String... K) {

		System.out.println("Enter the value ");
		int n = 3;
		int count = 1;
		int count2 = 1;
		char c = 'A';

		for (int i = 1; i < (n * 2); i++) {
			for (int spc = n - count2; spc > 0; spc--)
			// Logic to print space
			{
				System.out.print(" ");
			}
			if (i < n) {
				count2++;
			} else {
				count2--;
			}
			for (int j = 0; j < count; j++) {
				System.out.print(c);// Logic to print Character
				if (j < count / 2) {
					c++;
				} else {
					c--;
				}
			}
			if (i < n) {
				count = count + 2;
			} else {
				count = count - 2;
			}
			c = 'A';

			System.out.println();

		}
	}
}
